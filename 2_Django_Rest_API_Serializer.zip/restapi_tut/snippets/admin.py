from django.contrib import admin
from snippets.models import Snippet

# Register your models here.
admin.site.register(Snippet)